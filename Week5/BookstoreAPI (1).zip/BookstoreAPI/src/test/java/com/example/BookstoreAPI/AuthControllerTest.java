package com.example.BookstoreAPI;

import com.example.BookstoreAPI.controller.AuthController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        // Setup any necessary data or configurations before each test
    }

    @Test
    void testLogin() throws Exception {
        // When & Then
        mockMvc.perform(post("/auth/login")
                        .contentType("application/json")
                        .content("{\"username\": \"testuser\", \"password\": \"password\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").exists()); // Adjust this based on your actual response
    }

    @Test
    void testRegister() throws Exception {
        // When & Then
        mockMvc.perform(post("/auth/register")
                        .contentType("application/json")
                        .content("{\"username\": \"newuser\", \"password\": \"password\"}"))
                .andExpect(status().isCreated());
    }
}
