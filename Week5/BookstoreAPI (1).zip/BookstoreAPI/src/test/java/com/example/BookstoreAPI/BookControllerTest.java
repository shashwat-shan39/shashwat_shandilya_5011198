package com.example.BookstoreAPI;


import com.example.BookstoreAPI.controller.BookController;
import com.example.BookstoreAPI.entity.Book;
import com.example.BookstoreAPI.repository.BookRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@WebMvcTest(BookController.class)
class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookRepository bookRepository;

    private Book book;

    @BeforeEach
    void setUp() {
        // Initialize a Book object for use in the tests
        book = new Book();
        book.setId(1L);
        book.setTitle("Spring Boot in Action");
        book.setAuthor("Craig Walls");
        book.setPrice(29.99);
        book.setIsbn("1234567890123");
    }

    @Test
    void testGetAllBooks() throws Exception {
        // Given
        given(bookRepository.findAll()).willReturn(Collections.singletonList(book));

        // When & Then
        mockMvc.perform(get("/books")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(book.getId()))
                .andExpect(jsonPath("$[0].title").value(book.getTitle()))
                .andExpect(jsonPath("$[0].author").value(book.getAuthor()))
                .andExpect(jsonPath("$[0].price").value(book.getPrice()))
                .andExpect(jsonPath("$[0].isbn").value(book.getIsbn()));
    }

    @Test
    void testGetBookById() throws Exception {
        // Given
        given(bookRepository.findById(Math.toIntExact(anyLong()))).willReturn(Optional.of(book));

        // When & Then
        mockMvc.perform(get("/books/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(book.getId()))
                .andExpect(jsonPath("$.title").value(book.getTitle()))
                .andExpect(jsonPath("$.author").value(book.getAuthor()))
                .andExpect(jsonPath("$.price").value(book.getPrice()))
                .andExpect(jsonPath("$.isbn").value(book.getIsbn()));
    }

    @Test
    void testCreateBook() throws Exception {
        // Given
        given(bookRepository.save(any(Book.class))).willReturn(book);

        // When & Then
        mockMvc.perform(post("/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"title\": \"Spring Boot in Action\", \"author\": \"Craig Walls\", \"price\": 29.99, \"isbn\": \"1234567890123\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(book.getId()))
                .andExpect(jsonPath("$.title").value(book.getTitle()))
                .andExpect(jsonPath("$.author").value(book.getAuthor()))
                .andExpect(jsonPath("$.price").value(book.getPrice()))
                .andExpect(jsonPath("$.isbn").value(book.getIsbn()));
    }

    @Test
    void testUpdateBook() throws Exception {
        // Given
        given(bookRepository.findById(Math.toIntExact(anyLong()))).willReturn(Optional.of(book));
        given(bookRepository.save(any(Book.class))).willReturn(book);

        // When & Then
        mockMvc.perform(put("/books/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"title\": \"Spring Boot in Action\", \"author\": \"Craig Walls\", \"price\": 39.99, \"isbn\": \"1234567890123\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(book.getId()))
                .andExpect(jsonPath("$.title").value(book.getTitle()))
                .andExpect(jsonPath("$.author").value(book.getAuthor()))
                .andExpect(jsonPath("$.price").value(39.99))
                .andExpect(jsonPath("$.isbn").value(book.getIsbn()));
    }

    @Test
    void testDeleteBook() throws Exception {
        // Given
        given(bookRepository.findById(Math.toIntExact(anyLong()))).willReturn(Optional.of(book));

        // When & Then
        mockMvc.perform(delete("/books/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }
}
