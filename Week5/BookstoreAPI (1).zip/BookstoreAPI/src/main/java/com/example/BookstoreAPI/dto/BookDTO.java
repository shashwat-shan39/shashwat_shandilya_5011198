package com.example.BookstoreAPI.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BookDTO {
    private Long id;

    @NotNull(message = "Title cannot be null")
    @Size(min = 1, message = "Title must not be empty")
    private String title;

    @NotNull(message = "Author cannot be null")
    @Size(min = 1, message = "Author must not be empty")
    private String author;

    @Min(value = 0, message = "Price must be greater than or equal to 0")
    private double price;

    @NotNull(message = "ISBN cannot be null")
    @Size(min = 10, max = 13, message = "ISBN must be between 10 and 13 characters")
    private String isbn;
}
