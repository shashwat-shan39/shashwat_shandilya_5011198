package com.example.EmployeeManagementSystem.projection;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmployeeDetailsDTO {
    private String name;
    private String departmentName;
}
