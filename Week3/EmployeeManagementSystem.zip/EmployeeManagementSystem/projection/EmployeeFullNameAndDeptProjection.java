package com.example.EmployeeManagementSystem.projection;

import org.springframework.beans.factory.annotation.Value;

public interface EmployeeFullNameAndDeptProjection {
    @Value("#{target.name + ' (' + target.department.name + ')'}")
    String getFullNameWithDepartment();
}
