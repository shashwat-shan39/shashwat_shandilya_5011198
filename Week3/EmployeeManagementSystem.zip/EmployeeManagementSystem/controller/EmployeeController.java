package com.example.EmployeeManagementSystem.controller;


import com.example.EmployeeManagementSystem.entity.primary.Employee;
import com.example.EmployeeManagementSystem.projection.EmployeeDetailsDTO;
import com.example.EmployeeManagementSystem.projection.EmployeeFullNameAndDeptProjection;
import com.example.EmployeeManagementSystem.repository.EmployeeRepository;
import com.example.EmployeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private EmployeeRepository employeeRepository;

    @PostMapping
    public ResponseEntity<?> createEmployee(@RequestBody Employee employee) {
        try {
            Employee createdEmployee = employeeService.createEmployee(employee);
            return ResponseEntity.ok(createdEmployee);
        } catch (Exception e) {
            // Log and return a more detailed error message
            System.err.println("Controller error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create employee: " + e.getMessage());
        }
    }
    @GetMapping
    public ResponseEntity<List<Employee>>getAllEmployees()
    {
        List<Employee>employees=employeeService.getEmployee();
        return ResponseEntity.ok(employees);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Optional<Employee>> getEmployeeById(@PathVariable Integer id)
    {
        Optional<Employee> employee=employeeService.getEmployeeById(id);
        return ResponseEntity.ok(employee);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Integer id, @RequestBody Employee employeeDetails) {
        Employee updatedEmployee = employeeService.updateEmployee(id, employeeDetails);
        return ResponseEntity.ok(updatedEmployee);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Integer id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/search")
    public ResponseEntity<List<Employee>> searchByName(@RequestParam("name") String name) {
        List<Employee> employees = employeeService.findByName(name);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/searchByEmail")
    public ResponseEntity<Employee> searchByEmail(@RequestParam("email") String email) {
        Employee employee = employeeService.findEmployeeByEmail(email);
        return ResponseEntity.ok(employee);
    }

    // Pagination and Sorting

    @GetMapping("/paginated")
    public ResponseEntity<Page<Employee>> getPaginatedEmployees(
            @PageableDefault(size = 10, sort = "name") Pageable pageable) {

        Page<Employee> employees = employeeService.findAll(pageable);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/searchByDepartment")
    public ResponseEntity<Page<Employee>> searchByDepartmentName(
            @RequestParam("departmentName") String departmentName,
            @PageableDefault(size = 10, sort = "name") Pageable pageable) {

        Page<Employee> employees = employeeService.findByDepartmentName(departmentName, pageable);
        return ResponseEntity.ok(employees);
    }
    @GetMapping("/details")
    public ResponseEntity<List<EmployeeDetailsDTO>> getEmployeeDetails() {
        List<EmployeeDetailsDTO> employeeDetails = employeeRepository.findEmployeeDetails();
        return ResponseEntity.ok(employeeDetails);
    }

    @GetMapping("/fullname-department")
    public ResponseEntity<List<EmployeeFullNameAndDeptProjection>> getEmployeeFullNameAndDept() {
        List<EmployeeFullNameAndDeptProjection> employeeData = employeeRepository.findBy();
        return ResponseEntity.ok(employeeData);
    }
}
