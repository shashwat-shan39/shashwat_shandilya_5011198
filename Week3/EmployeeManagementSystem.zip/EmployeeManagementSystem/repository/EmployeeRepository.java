package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.primary.Employee;
import com.example.EmployeeManagementSystem.projection.EmployeeDetailsDTO;
import com.example.EmployeeManagementSystem.projection.EmployeeFullNameAndDeptProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
    List<Employee> findByName(String name);

    // Find employees by department name
    List<Employee> findByDepartmentName(String departmentName);

    // Custom query to find employee by email
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee findEmployeeByEmail(@Param("email") String email);

    // Pagination and Sorting
    Page<Employee> findAll(Pageable pageable);
    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);
    @Query("SELECT new com.example.EmployeeManagementSystem.projection.EmployeeDetailsDTO(e.name, e.department.name) FROM Employee e")
    List<EmployeeDetailsDTO> findEmployeeDetails();

    List<EmployeeFullNameAndDeptProjection> findBy();
}
