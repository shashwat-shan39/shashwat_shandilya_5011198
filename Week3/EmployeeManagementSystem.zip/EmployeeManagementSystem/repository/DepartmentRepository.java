package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.primary.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department,Integer> {
    List<Department>findByName(String name);
}
